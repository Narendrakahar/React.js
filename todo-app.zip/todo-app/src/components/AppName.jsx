import css from "./AppName.module.css";

const AppName = () => {
  return <h1 className={css.h1}>Todo App</h1>;
};

export default AppName;
