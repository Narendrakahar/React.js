import css from "./WelcomeMessage.module.css";

const WelcomeMessage = () => {
  return <p className={css.welcome}>Enjoy Your Day</p>;
};

export default WelcomeMessage;
