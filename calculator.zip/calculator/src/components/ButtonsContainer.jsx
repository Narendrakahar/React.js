import css from "./ButtonsContainer.module.css";

const ButtonsContainer = ({ onButtonClick }) => {
  const ButtonNames = [
    "1",
    "2",
    "C",
    "3",
    "4",
    "+",
    "5",
    "6",
    "-",
    "7",
    "8",
    "*",
    "9",
    "0",
    "/",
    ".",
    "=",
  ];

  return (
    <div className={css.buttonsContainer}>
      {ButtonNames.map((buttonName) => {
        let buttonClass = css.button;
        if (buttonName === "C")
          buttonClass = `${css.button} ${css.clearButton}`;
        if (["+", "-", "*", "/"].includes(buttonName))
          buttonClass = `${css.button} ${css.operatorButton}`;
        if (buttonName === "=")
          buttonClass = `${css.button} ${css.equalsButton}`;
        return (
          <button
            key={buttonName}
            className={buttonClass}
            onClick={() => onButtonClick(buttonName)}
          >
            {buttonName}
          </button>
        );
      })}
    </div>
  );
};

export default ButtonsContainer;
