import css from "./App.module.css";
import Display from "./components/Display";
import ButtonsContainer from "./components/ButtonsContainer";
import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";

function App() {
  const [calVal, setCalVal] = useState("");

  const handleButtonClick = (buttonName) => {
    if (buttonName === "C") {
      setCalVal("");
    } else if (buttonName === "=") {
      const result = eval(calVal);
      setCalVal(result);
    } else {
      const newDisplayVal = calVal + buttonName;
      setCalVal(newDisplayVal);
    }
    console.log(`${buttonName} button Clicked.`);
  };

  return (
    <div className={css.calculator}>
      <Display displayVal={calVal} />
      <ButtonsContainer onButtonClick={handleButtonClick} />
    </div>
  );
}

export default App;
